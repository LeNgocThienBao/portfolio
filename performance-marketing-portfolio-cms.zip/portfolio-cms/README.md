# Performance Marketing Portfolio — CMS starter

This package converts the existing static Portfolio v2 into a Cloudflare Workers + D1 CMS.

## Included
- `public/index.html`: existing Portfolio v2 with content loaded from `/api/content`.
- `public/admin.html`: password-protected admin UI at `/admin`.
- `src/worker.js`: Worker API, signed HttpOnly session cookie, content read/write.
- `schema.sql`: D1 schema.
- `content.default.json`: initial editable content (preserves current placeholders; no invented metrics).
- `wrangler.toml`: deployment configuration template.

## Cloudflare setup required before deployment
1. Create a D1 database named `portfolio-cms` and run `schema.sql`.
2. Put the returned D1 database ID into `wrangler.toml`.
3. Set Worker secrets:
   - `ADMIN_PASSWORD`: choose a strong unique admin password.
   - `SESSION_SECRET`: a random secret of at least 32 bytes.
4. Deploy with Wrangler (`npx wrangler deploy`).

The first `/api/content` request seeds the database from `public/content.default.json`.

## Security notes
- Admin password is stored as a Worker secret, not in frontend code or D1.
- Session cookie is HttpOnly, Secure, SameSite=Strict and expires after 12 hours.
- `/admin` is `noindex`; all write requests require a valid signed session and same-origin request.
- Use HTTPS and never paste `ADMIN_PASSWORD` or `SESSION_SECRET` into chat.

## Media
This first CMS version accepts public image/video URLs in project records. Direct uploads require adding an R2 bucket and media-serving policy in a subsequent step.
