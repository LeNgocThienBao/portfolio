const COOKIE_NAME = "portfolio_admin";
const SESSION_SECONDS = 60 * 60 * 12;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers } });
}
function b64url(bytes) {
  let s = "";
  for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
  return btoa(s).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function fromB64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return Uint8Array.from(atob(s), c => c.charCodeAt(0));
}
async function hmac(value, secret) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64url(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}
async function safeEqual(a, b) {
  const [x, y] = await Promise.all([crypto.subtle.digest("SHA-256", new TextEncoder().encode(a)), crypto.subtle.digest("SHA-256", new TextEncoder().encode(b))]);
  const xa = new Uint8Array(x), ya = new Uint8Array(y);
  let diff = 0;
  for (let i = 0; i < xa.length; i++) diff |= xa[i] ^ ya[i];
  return diff === 0;
}
async function createSession(secret) {
  const payload = b64url(new TextEncoder().encode(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + SESSION_SECONDS, nonce: crypto.randomUUID() })));
  return `${payload}.${await hmac(payload, secret)}`;
}
async function validSession(request, secret) {
  const cookie = request.headers.get("cookie") || "";
  const token = cookie.split(";").map(v => v.trim()).find(v => v.startsWith(COOKIE_NAME + "="))?.slice(COOKIE_NAME.length + 1);
  if (!token || !secret) return false;
  const [payload, signature] = token.split(".");
  if (!payload || !signature || !(await safeEqual(signature, await hmac(payload, secret)))) return false;
  try { return JSON.parse(new TextDecoder().decode(fromB64url(payload))).exp > Math.floor(Date.now() / 1000); } catch { return false; }
}
function sameOrigin(request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  return new URL(origin).host === new URL(request.url).host;
}
async function readContent(env) {
  const row = await env.DB.prepare("SELECT content_json FROM portfolio_content WHERE id = 'main'").first();
  if (row?.content_json) return JSON.parse(row.content_json);
  const fallback = await env.ASSETS.fetch(new Request(new URL("/content.default.json", "https://assets.local")));
  const content = await fallback.json();
  await env.DB.prepare("INSERT OR IGNORE INTO portfolio_content (id, content_json) VALUES ('main', ?)").bind(JSON.stringify(content)).run();
  return content;
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/login" && request.method === "POST") {
      if (!sameOrigin(request)) return json({ error: "Invalid origin" }, 403);
      if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({ error: "Admin secrets are not configured. Set ADMIN_PASSWORD and SESSION_SECRET in Worker secrets." }, 503);
      const body = await request.json().catch(() => ({}));
      const password = String(body.password || "");
      if (!(await safeEqual(password, env.ADMIN_PASSWORD))) return json({ error: "Mật khẩu không chính xác." }, 401);
      const token = await createSession(env.SESSION_SECRET);
      return json({ ok: true }, 200, { "set-cookie": `${COOKIE_NAME}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_SECONDS}` });
    }
    if (url.pathname === "/api/logout" && request.method === "POST") {
      return json({ ok: true }, 200, { "set-cookie": `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });
    }
    if (url.pathname === "/api/session" && request.method === "GET") {
      return json({ authenticated: await validSession(request, env.SESSION_SECRET) });
    }
    if (url.pathname === "/api/content" && request.method === "GET") {
      try { return json(await readContent(env), 200, { "cache-control": "public, max-age=60, s-maxage=60" }); }
      catch { return json({ error: "Content database is not initialized. Check D1 binding and migration." }, 500); }
    }
    if (url.pathname === "/api/content" && request.method === "PUT") {
      if (!sameOrigin(request)) return json({ error: "Invalid origin" }, 403);
      if (!(await validSession(request, env.SESSION_SECRET))) return json({ error: "Unauthorized" }, 401);
      const content = await request.json().catch(() => null);
      if (!content || typeof content !== "object" || !Array.isArray(content.projects) || !Array.isArray(content.tools)) return json({ error: "Invalid content structure" }, 400);
      const serialized = JSON.stringify(content);
      if (serialized.length > 900_000) return json({ error: "Nội dung quá lớn. Hãy giảm dung lượng hoặc dùng URL media." }, 413);
      await env.DB.prepare("INSERT INTO portfolio_content (id, content_json, updated_at) VALUES ('main', ?, CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET content_json = excluded.content_json, updated_at = CURRENT_TIMESTAMP").bind(serialized).run();
      return json({ ok: true, updatedAt: new Date().toISOString() });
    }
    if (url.pathname === "/admin" || url.pathname === "/admin/") return env.ASSETS.fetch(new Request(new URL("/admin.html", request.url)));
    return env.ASSETS.fetch(request);
  }
};
